how to run my program:
	python assignment8.py

This will output to a file called data.txt. 

This file will
have all of the tables. They are separated by a header 
"********** NAME OF PROBABILITY **********"
"FORMATED PROBABILITY EQUATION" example: P(Xt|X+1)

Each different probability inside that type of probability
is separated by a space for readability.

I worked with Brooke Robinson and Jennifer Michael on this.