#Assignment 8
#worked with Brooke Robinson and Jennifer Michael

from string import ascii_lowercase #just gets the alphabet in lower case


class LetterN:
	
	def __init__(self, name):
		self.name = name
		self.count = 0.0

		self.evidenceDict = {} #evidenceDict['a'] = 7, number of times a was seen in current state
		self.nextevidenceDict = {} #just stores next evidence
		self.probEDict = {} #probEDict['a'] = 0.47, prob of seeing a in the current state
		self.probTDict = {} #transition prob, P(Xt+1 | Xts)
		
def calcEmmision(file):
	
	allnodes = []

	for letter in ascii_lowercase:
		curLetterN = LetterN(str(letter))
		allnodes.append(curLetterN)
		#reads each line of the file and constructs an evidence count
		with open("typos20.data", "r") as myFile:
			for line in myFile:
				x = 0
				e = 2
				if line[x] == letter: #does x[s] == letter in alphabet we are at
					curLetterN.count += 1.0
					# e[s] == x[s]
					if line[e] in curLetterN.evidenceDict:
						curLetterN.evidenceDict[line[e]] += 1 #add to counter
					else:
						curLetterN.evidenceDict[line[e]] = 1 #create entry

		#deniminator = count of the current letter  + number of letters observed when X = a
		#adds 2 due to smoothing method, Laplace smoothing

		print("")
		file.write("\n")

		denominator = float(curLetterN.count + len(curLetterN.evidenceDict.keys())+2.0)


		for key in sorted(curLetterN.evidenceDict):
			numerator = float(curLetterN.evidenceDict[key]) + 1.0
			prob = numerator/denominator
			curLetterN.probEDict[key] = prob
			print("P( {0} | {1} ) = {2}").format(key, curLetterN.name ,round(curLetterN.probEDict[key],6))
			file.write("P( {0} | {1} ) = {2} \n".format(key, curLetterN.name ,round(curLetterN.probEDict[key],6)))

	print("")
	file.write("\n")
	return(allnodes)

def calcTransition(allnodes,file):

	
	for node in allnodes:
		curLetterN = node

		with open("typos20.data", "r") as myFile:
			iterFile = iter(myFile) #used to traverse through the file
			for line in iterFile:
	 			x = 0
				if line[x] == curLetterN.name:
					nextline = next(iterFile,None)

					if (nextline == None):
						break #we are at the end of the file
					else:
						if (nextline[x] in curLetterN.nextevidenceDict):
							curLetterN.nextevidenceDict[nextline[x]] += 1 #add to counter
						else:
							curLetterN.nextevidenceDict[nextline[x]] = 1 #create entry

		#set the rest if the probabilities to zero
		for letter in ascii_lowercase:
			if letter not in curLetterN.nextevidenceDict.keys():
				curLetterN.nextevidenceDict[letter] = 0

		#deniminator = count of the current letter  + number of letters observed when X = a
		#adds 2 due to smoothing method, Laplace smoothing
		denominator = float(curLetterN.count + len(curLetterN.nextevidenceDict.keys())+2.0)

		print("")
		file.write("\n")

		for key in sorted(curLetterN.nextevidenceDict):
			
			numerator = float(curLetterN.nextevidenceDict[key]) + 1.0
			prob = numerator/denominator
			curLetterN.probTDict[key] = prob
			print("P( {0} | {1} ) = {2}").format(key, curLetterN.name ,round(curLetterN.probTDict[key],6))
			file.write("P( {0} | {1} ) = {2}\n".format(key, curLetterN.name ,round(curLetterN.probTDict[key],6)))

	print("")
	file.write("\n")

def calcMarginalInitial(allnodes,file):

	initStatesDict = []

	linestotal = 0
	with open("typos20.data", "r") as myFile:
		for line in myFile:
			if line[0] != "_":
				linestotal += 1

	for node in allnodes:
		node.initialstate = float(node.count+1)/float(linestotal+2)
		initStatesDict.append(node.initialstate)
		print("P({0}) =  {1}").format(node.name, round(node.initialstate,6))
		file.write("P({0}) =  {1}\n".format(node.name, round(node.initialstate,6)))



def main():

	file = open("data.txt","w")

	print("**********  emmision probabilities  **********")
	file.write("**********  emmision probabilities  **********\n")
	print("P(Et | Xt)")
	file.write("P(Et | Xt)\n")
	allnodes = calcEmmision(file)
	print("**********  transition probabilities  **********")
	file.write("************************************************\n")
	file.write("**********  transition probabilities  **********\n")
	file.write("************************************************\n")
	print("P(Xt+1 | Xt)")
	file.write("P(Xt+1 | Xt)\n")
	calcTransition(allnodes,file)
	print("**********  marginal.initial probabilities  **********\n")
	file.write("**********  marginal/initial probabilities  **********\n")
	calcMarginalInitial(allnodes,file)
	file.close()
	
if __name__ == '__main__':
	main()
